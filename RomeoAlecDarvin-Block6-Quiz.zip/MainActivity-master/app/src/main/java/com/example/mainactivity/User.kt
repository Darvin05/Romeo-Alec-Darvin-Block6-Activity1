package com.example.pchub.Activities

data class User (
    var id: Int = -1,
    var username: String = "",
    var email: String = "",
    var password: String = "",
    var confirm: String = ""
)